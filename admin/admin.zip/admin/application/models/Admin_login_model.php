<?php 
class Admin_login_model extends CI_Model 
{
 
	function validate_login($username,$password)
	{
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		$query=$this->db->get('user');

		if($query->num_rows()==1)
		{
			$row=$query->row();
			$data=array(
				'id'=>$row->id,
				'username'=>$row->username,
				'password'=>$row->password,
				'validate'=>true
			);
			$this->session->set_userdata($data);
			return true;
		}
		else{
			return false;
		}
	}
}
?>