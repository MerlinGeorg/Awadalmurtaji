<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_homeslider extends CI_Controller {
	function __construct()
	 {
    	parent::__construct();
    	$this->load->helper('url'); 
    	
	 }

	 public function index()
	{
	    $a = array('content' => 'admin_homeslider_view');
	    $this->load->view('admintemplate',$a);
	}
}