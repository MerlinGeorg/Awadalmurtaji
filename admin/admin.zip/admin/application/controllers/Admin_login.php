<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Controller {

	public function __construct()
   {
     parent::__construct();
     $this->load->helper('url');
     $this->load->library('session');
     $this->load->model('Admin_login_model');
 }
 public function index()
 {
 	 
 	 $username = $this->security->xss_clean($this->input->post('uname'));
 	 $password=$this->security->xss_clean($this->input->post('pass'));
 	 $result = $this->Admin_login_model->validate_login($username,$password);

 	 if(!$result)
 	 { ?>
 	 	/<!--<script>
 	 	alert('failed');
 	 	</script>-->

 	 	<?php 
 	 	$a=array('content'=>'dashboard_view');
 	 	$this->load->view('admin_login_view');
 	 }
 	 else{
 	 	redirect('Admin_login/welcome');
 	 }
 }

 public function welcome(){
 	if(isset($_SESSION['username']))
 	{
 		$a=array('content'=>'dashboard_view');
 		$this->load->view('admintemplate',$a);
 	}	
 }
 public function logout(){
 	$this->session->sess_destroy();
 	$this->load->view('admin_login_view');
 }
}
?>