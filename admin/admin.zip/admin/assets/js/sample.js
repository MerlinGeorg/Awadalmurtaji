function test() { 
   alert('test'); 
}